package com.example.fragmenappsdhilafadhilah;

import android.app.Activity;

public class SecondActivity extends Activity {
}
